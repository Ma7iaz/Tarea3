package tarea3;
import java.awt.*;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Ventana extends JFrame {
    public Ventana() {
        this.setLayout(new BorderLayout());
        this.setSize(1300,670);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        PanelCentral pc = new PanelCentral();
        this.add(pc,BorderLayout.CENTER);        
        
        this.setVisible(true);
    }
}