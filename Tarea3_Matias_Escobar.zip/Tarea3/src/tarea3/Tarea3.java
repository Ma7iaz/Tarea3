package tarea3;

public class Tarea3 {
    public static void main(String[] args) {
        Ventana v = new Ventana();
    }
}