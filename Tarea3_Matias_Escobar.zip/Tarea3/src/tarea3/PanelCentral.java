package tarea3;
import java.awt.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.*;

public class PanelCentral extends JPanel implements MouseListener {
    private Expendedor exp;
    private Cuadro cuadroCoca, cuadroSprite, cuadroBeber, llenarCoca, llenarSprite, darMoneda100, darMoneda500, darMoneda1000, darMoneda1500;
    private Comprador com;
    private Moneda m = null;
    public PanelCentral() {
        this.setBackground(Color.cyan);
        exp = new Expendedor(900, 50);
        cuadroCoca = new Cuadro(935, 550, 100, 50);
        cuadroSprite = new Cuadro(1095, 550, 100, 50);
        llenarCoca = new Cuadro(935, 10, 100, 30);
        llenarSprite = new Cuadro(1095, 10, 100, 30);
        darMoneda100 = new Cuadro(0, 500, 100, 20);
        darMoneda500 = new Cuadro(0, 525, 100, 20);
        darMoneda1000 = new Cuadro(0, 550, 100, 20);
        darMoneda1500 = new Cuadro(0, 575, 100, 20);
        com = new Comprador(200, 310);
        this.addMouseListener(this);
        exp.llenarMoneda(7, 100);
        exp.llenarMoneda(7, 500);
    }   
    public void paint(Graphics g) {
        super.paint(g);
        if(exp != null) exp.paint(g, Color.gray);
        if(cuadroCoca != null) cuadroCoca.paint(g, Color.blue, "Comprar CocaCola");
        if(cuadroSprite != null) cuadroSprite.paint(g, Color.blue, "Comprar Sprite");
        if(cuadroBeber != null) cuadroBeber.paint(g, Color.yellow, "Beber");
        if(llenarCoca != null) llenarCoca.paint(g, Color.yellow, "Llenar CocaCola");
        if(llenarSprite != null) llenarSprite.paint(g, Color.yellow, "Llenar Sprite");
        if(darMoneda100 != null) darMoneda100.paint(g, Color.yellow, "Dar Moneda 100");
        if(darMoneda500 != null) darMoneda500.paint(g, Color.yellow, "Dar Moneda 500");
        if(darMoneda1000 != null) darMoneda1000.paint(g, Color.yellow, "Dar Moneda 1000");
        if(darMoneda1500 != null) darMoneda1500.paint(g, Color.yellow, "Dar Moneda 1500");
        if(com != null) com.paint(g);
    }
    public void mouseClicked(MouseEvent e) {;}
    public void mousePressed(MouseEvent e) {
        if(cuadroCoca != null) {
            if(cuadroCoca.clickDentro(e.getX(), e.getY())) {
                if(m != null) {
                    Bebida b = com.comprarBebida(1, exp);
                    if (b != null) {
                        cuadroBeber = new Cuadro(340, 490, 40, 20);
                        m = null;
                    } else {
                        llenarCoca = new Cuadro(935, 10, 100, 30);
                        darMoneda100 = new Cuadro(0, 500, 100, 20);
                        darMoneda500 = new Cuadro(0, 525, 100, 20);
                        darMoneda1000 = new Cuadro(0, 550, 100, 20);
                        darMoneda1500 = new Cuadro(0, 575, 100, 20);
                    }
                }
                else System.out.println("Sin suficiente dinero");
                repaint();
            }
        }
        if(cuadroSprite != null) {
            if(cuadroSprite.clickDentro(e.getX(), e.getY())){
                if(m != null){
                    Bebida b = com.comprarBebida(2, exp);
                    if (b != null){
                        cuadroBeber = new Cuadro(340, 490, 40, 20);
                        m = null;
                    } else {
                        llenarSprite = new Cuadro(1095, 10, 100, 30);
                        darMoneda100 = new Cuadro(0, 500, 100, 20);
                        darMoneda500 = new Cuadro(0, 525, 100, 20);
                        darMoneda1000 = new Cuadro(0, 550, 100, 20);
                        darMoneda1500 = new Cuadro(0, 575, 100, 20);
                    }
                }
                else System.out.println("Sin suficiente dinero");
                repaint();
            }
        }
        if(cuadroBeber != null) {
            if(cuadroBeber.clickDentro(e.getX(), e.getY())) {
                com.beber();
                cuadroBeber = null;
                darMoneda100 = new Cuadro(0, 500, 100, 20);
                darMoneda500 = new Cuadro(0, 525, 100, 20);
                darMoneda1000 = new Cuadro(0, 550, 100, 20);
                darMoneda1500 = new Cuadro(0, 575, 100, 20);
                repaint();
            }
        }
        if(llenarCoca != null) {
            if(llenarCoca.clickDentro(e.getX(), e.getY())) {
                exp.llenar(16, 300, 1);
                llenarCoca = null;
                repaint();
            }
        }
        if(llenarSprite != null) {
            if(llenarSprite.clickDentro(e.getX(), e.getY())) {
                exp.llenar(16, 300, 2);
                llenarSprite = null;
                repaint();
            }
        }
        if(darMoneda100 != null) { 
            if(darMoneda100.clickDentro(e.getX(), e.getY())) {
                m = new Moneda100(10, 10);
                darMoneda100 = null;
                darMoneda500 = null;
                darMoneda1000 = null;
                darMoneda1500 = null;
                com.darMoneda(m);
                repaint();
            }
        }
        if(darMoneda500 != null) { 
            if(darMoneda500.clickDentro(e.getX(), e.getY())) {
                m = new Moneda500(10, 10);
                darMoneda100 = null;
                darMoneda500 = null;
                darMoneda1000 = null;
                darMoneda1500 = null;
                com.darMoneda(m);
                repaint();
            }
        }
        if(darMoneda1000 != null) { 
            if(darMoneda1000.clickDentro(e.getX(), e.getY())) {
                m = new Moneda1000(10, 10);
                darMoneda100 = null;
                darMoneda500 = null;
                darMoneda1000 = null;
                darMoneda1500 = null;
                com.darMoneda(m);
                repaint();
            }
        }
        if(darMoneda1500 != null) { 
            if(darMoneda1500.clickDentro(e.getX(), e.getY())) {
                m = new Moneda1500(10, 10);
                darMoneda100 = null;
                darMoneda500 = null;
                darMoneda1000 = null;
                darMoneda1500 = null;
                com.darMoneda(m);
                repaint();
            }
        }
    }
    public void mouseReleased(MouseEvent e) {;}
    public void mouseEntered(MouseEvent e) {;}
    public void mouseExited(MouseEvent e) {;}
}

class Cuadro {
    private int x,  y;
    private int tamx, tamy;
    public Cuadro(int x, int y, int tamx, int tamy) {
        this.x = x; this.tamx = tamx;
        this.y = y; this.tamy = tamy;
    }
    public void paint(Graphics g, Color c, String s) {
        g.setColor(c);
        g.fillRect(x, y, tamx, tamy);  
        g.setColor(Color.black);
        g.drawString(s, x, y + (tamy / 2) + 2);
    }
    public boolean clickDentro(int x, int y) {
        boolean click = false;
        if(this.x <= x && this.x + tamx >= x && this.y <= y && this.y + tamy >= y) click = true;
        return click;
    }
}

class Comprador {
    private String sonido;
    private int vuelto;
    private int x, y;
    private boolean manoVacia;
    private Bebida compra, anterior;
    private Moneda monedaCompra;
    private DepositoMonedas vueltos;
    public Comprador(int x, int y) {
        this.x = x;
        this.y = y;
        manoVacia = true;
        vueltos = new DepositoMonedas(x - 100, y + 80, 50, 240);
    }
    public void darMoneda(Moneda m) {
        monedaCompra = m;
        monedaCompra.setXY(x - 40, y + 180);
    }
    public Bebida comprarBebida(int cualBebida, Expendedor exp) {
        if(manoVacia) {
            compra = exp.comprarBebida(monedaCompra, cualBebida);
            Moneda moneda = exp.getVuelto();
            for(int i = 0; moneda != null; ++i) {
                vueltos.addMoneda(moneda);
                vuelto += moneda.getValor();
                moneda = exp.getVuelto();
            }
            if(compra != null) compra.setXY(x + 90, y + 180);
            return compra;
        }
        return anterior;
    }
    public void beber() {
        compra = null;
        anterior = null;
        manoVacia = true;
    }
    public int cuantoVuelto() {
        return vuelto;
    }
    public boolean manoVacia() {
        return manoVacia;
    }
    public String queBebiste() {
        return sonido;
    }
    public void paint(Graphics g) {
        g.setColor(Color.pink);     g.fillRect(x, y, 80, 80); //cabeza
        g.setColor(Color.darkGray); g.fillRect(x, y, 80, 20); //pelo
        g.setColor(Color.pink);     g.fillRect(x - 40, y + 180, 160, 20); //manos
        g.setColor(Color.white);    g.fillRect(x - 40, y + 80, 160, 100); //ropa
        g.setColor(Color.white);    g.fillRect(x, y + 80, 80, 120); //ropa
        g.setColor(Color.blue);     g.fillRect(x, y + 200, 80, 120); //piernas
        g.setColor(Color.black);    g.fillRect(x, y + 300, 80, 20); //pies
        if(compra != null) {
            anterior = compra;
            compra.paint(g, compra.getColor());
            if(manoVacia) {
                manoVacia = false;
                monedaCompra = null;
            } else g.drawString("Debes beber primero", x - 15, y - 10);     
        }
        else if(anterior != null) {
            compra.paint(g, compra.getColor());
        }
        if(monedaCompra != null) monedaCompra.paint(g);
        if(vueltos != null) vueltos.paint(g, Color.cyan);
    }
}

class Expendedor {
    private int x, y;
    private Deposito coca;
    private Deposito sprite;
    private DepositoMonedas v, mon100, mon500, monRecibida;
    private int precio;
    public static final int  COCA = 1;
    public static final int  SPRITE = 2;
    
    public Expendedor(int x, int y) {
        this.x = x;
        this.y = y;
        v = new DepositoMonedas(this.x, this.y, 10, 10);
        monRecibida = new DepositoMonedas(this.x - 50, this.y + 320, 50, 260);
        mon100 = new DepositoMonedas(this.x + 330, this.y + 450, 50, 130);
        mon500 = new DepositoMonedas(this.x + 330, this.y + 320, 50, 130);
        coca = new Deposito(this.x + 10, this.y + 20);
        sprite = new Deposito(this.x + 170, this.y + 20);
    }
    public void llenar(int cantidad, int precio, int cual) {
        this.precio = precio;
        if(cantidad > 16) cantidad = 16;
        if(cual == 1){
            for (int i = 0; i < cantidad; ++i){
            Bebida bc = new CocaCola(i, x, y);
            coca.addBebida(bc);
            }
        }
        if(cual == 2){
            for (int i = 0; i < cantidad; ++i){
            Bebida bs = new Sprite(i + 100, x, y);
            sprite.addBebida(bs);
            }
        }
    }
    public void llenarMoneda(int cantidad, int cual) {
        if(cantidad > 7) cantidad = 7;
        if(cual == 100){
            for (int i = 0; i < cantidad; ++i){
            Moneda mon = new Moneda100(x, y);
            mon100.addMoneda(mon);
            }
        }
        if(cual == 500){
            for (int i = 0; i < cantidad; ++i){
            Moneda mon = new Moneda500(x, y);
            mon500.addMoneda(mon);
            }
        }
    }
    public Bebida comprarBebida(Moneda m, int n) {
        Bebida b = null;
        switch(n) {
            case COCA: {
                if (m == null) return null;
                if (m.getValor() >= precio) {
                    b = coca.getBebida();
                    if (b != null) {
                        int vuelto = (m.getValor() - precio) / 100;
                        if(vuelto >= 5) {
                            for(int i = 0; i < vuelto;) {
                                Moneda moneda = mon500.getMoneda();
                                if(moneda == null) {
                                    this.llenarMoneda(7, 500);
                                    moneda = mon500.getMoneda();
                                }
                                v.addMoneda(moneda);
                                vuelto -= 5;
                                i += 5;
                            }
                        }
                        for(int i = 0; i < vuelto; ++i) {
                            Moneda moneda = mon100.getMoneda();
                            if(moneda == null){
                                this.llenarMoneda(7, 500);
                                moneda = mon100.getMoneda();
                            }
                            v.addMoneda(mon100.getMoneda());
                        }
                        monRecibida.addMoneda(m);
                    } else {
                        v.addMoneda(m);
                    }   
                    return b;     
                    }
                else {
                    v.addMoneda(m);
                    return b;
                }
            }
            case SPRITE: {
                if (m == null) return null;
                if (m.getValor() >= precio) {
                    b = sprite.getBebida();
                    if (b != null){
                        int vuelto = (m.getValor() - precio) / 100;
                        if(vuelto >= 5){
                            for(int i = 0; i < vuelto;) {
                                Moneda moneda = mon500.getMoneda();
                                if(moneda == null) {
                                    this.llenarMoneda(7, 500);
                                    moneda = mon500.getMoneda();
                                }
                                v.addMoneda(moneda);
                                vuelto -= 5;
                                i += 5;
                            }
                        }
                        for(int i = 0; i < vuelto; ++i) {
                            Moneda moneda = mon100.getMoneda();
                            if(moneda == null) {
                                this.llenarMoneda(7, 500);
                                moneda = mon100.getMoneda();
                            }
                            v.addMoneda(moneda);
                        }
                        monRecibida.addMoneda(m);
                    } else {
                        v.addMoneda(m);
                    }
                    return b;     
                    }
                else {
                    v.addMoneda(m);
                    return b;
                }
            }
            default: {
                v.addMoneda(m);
                return b;
            }
        }
    }
    public Moneda getVuelto() {
        return v.getMoneda();
    }
    public void paint(Graphics g, Color c) {
        g.setColor(c);
        g.fillRect(x, y, 330, 580);
        g.setColor(Color.black);
        g.drawRect(x, y, 330, 580);
        if(coca != null) coca.paint(g, Color.red);
        if(sprite != null) sprite.paint(g, Color.green);
        if(mon100 != null) mon100.paint(g, Color.gray);
        if(mon500 != null) mon500.paint(g, Color.gray);
        if(monRecibida != null) monRecibida.paint(g, Color.gray);
    } 
}

class Deposito {
    private int x, y;  
    private ArrayList<Bebida> beb;
    public Deposito(int x, int y) {
        this.x = x;
        this.y = y;
        beb = new ArrayList<Bebida>();
    }
    public void paint(Graphics g, Color c) {
        g.setColor(Color.white);
        g.fillRect(x, y, 150, 480);  
        g.setColor(Color.black);
        g.drawRect(x, y, 150, 480);
        g.drawString("Precio: $300", x + 40, y - 5);
        for(int i = beb.size() - 1; i >= 0; --i) {
            Bebida aux = beb.get(i);
            aux.paint(g, c);
        }
    }
    public void addBebida(Bebida b) {
        beb.add(b);
        for(int i = 0; i < beb.size(); ++i) {
            Bebida aux = beb.get(i);
            aux.setXY(this.x + 65, this.y + 480 - (30 * i));
        }    
    }
    public Bebida getBebida() {
        Bebida aux = null;
        if (beb.size() > 0) {
            aux = beb.remove(0);
            for(int i = 0; i < beb.size(); ++i) {
                Bebida b = beb.get(i);
                b.setXY(x + 65, y + 480 - (30 * i));
            }
        }
        return aux;
    }
}

class DepositoMonedas { 
    private int x, y, tamx, tamy;
    private ArrayList<Moneda> m;
    public DepositoMonedas(int x, int y, int tamx, int tamy) {
        this.x = x; this.tamx = tamx;
        this.y = y; this.tamy = tamy;
        m = new ArrayList<Moneda>();
    }
    public void addMoneda(Moneda mon) {
        m.add(mon);
        for(int i = 0; i < m.size(); ++i){
            Moneda aux = m.get(i);
            aux.setXY(this.x + (tamx / 4), this.y + (tamy - 30) - (15 * i));
        } 
    }
    public void llenarMoneda(int cantidad, int cual) {
        if(cantidad > 5) cantidad = 5;
        if(cual == 100) {
            for (int i = 0; i < cantidad; ++i) {
                Moneda mon = new Moneda100(x, y);
                this.addMoneda(mon);
            }
        }
        if(cual == 500) {
            for (int i = 0; i < cantidad; ++i) {
                Moneda mon = new Moneda500(x, y);
                this.addMoneda(mon);
            }
        }
    }
    public Moneda getMoneda() {
        Moneda aux = null;
        if (m.size() > 0) {
            aux = m.remove(0);
            for(int i = 0; i < m.size(); ++i) {
                Moneda x = m.get(i);
                x.setXY(this.x + (tamx / 4), this.y + (tamy - 30) - (15 * i));
            }
        }
        return aux;
    }
    public void paint(Graphics g, Color c) {
        g.setColor(c);
        g.fillRect(x, y, tamx, tamy);
        g.setColor(Color.black);
        g.drawRect(x, y, tamx, tamy);
        for(int i = m.size() - 1; i >= 0; --i) {
            Moneda aux = m.get(i);
            aux.paint(g);
        }
    }
}

/********** BEBIDAS **********/
abstract class Bebida {
    private int serie;
    private int x, y;
    private Color color;
    public Bebida(int num, int x, int y) {
        serie = num;
        this.x = x;
        this.y = y;
    }
    public int getSerie() {
        return serie;
    }
    public Color getColor() {
        return color;
    }
    public void paint(Graphics g, Color c) {
        color = c;
        g.setColor(c);
        g.fillRect(this.x, this.y, 40, 20);
        g.setColor(Color.black);
        g.drawString(String.valueOf(serie), this.x, this.y + 15);
    }
    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public abstract String beber();
}
class CocaCola extends Bebida {
    public CocaCola(int num, int x, int y) {
        super(num, x, y);
    }  
    public String beber() {
        return ("cocacola");
    }
}
class Sprite extends Bebida {
    public Sprite(int num, int x, int y) {
        super(num, x, y);
    } 
    public String beber() {
        return ("sprite");
    }
}

/********** MONEDAS **********/
abstract class Moneda {
    private int x, y;
    public Moneda(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public Moneda getSerie() {
        return this;
    }
    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public void paint(Graphics g) {
        g.setColor(Color.yellow);
        g.fillOval(x, y, 25, 25);
        g.setColor(Color.black);
        g.drawOval(x, y, 25, 25);
        g.drawString(String.valueOf(this.getValor()), this.x + 2, this.y + 17);
    }
    public abstract int getValor();
}
class Moneda1500 extends Moneda { 
    public Moneda1500(int x, int y) {
        super(x, y);
    }
    public int getValor() {
        return 1500;
    }
}
class Moneda1000 extends Moneda { 
    public Moneda1000(int x, int y) {
        super(x, y);
    }
    public int getValor() {
        return 1000;
    }
}
class Moneda500 extends Moneda { 
    public Moneda500(int x, int y) {
        super(x, y);
    }
    public int getValor() {
        return 500;
    }
}
class Moneda100 extends Moneda { 
    public Moneda100(int x, int y) {
        super(x, y);
    }
    public int getValor() {
        return 100;
    }
}